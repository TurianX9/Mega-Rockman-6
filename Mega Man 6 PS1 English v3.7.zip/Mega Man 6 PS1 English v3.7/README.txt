MEGA MAN 6 - PLAYSTATION COMPLETE WORKS
ENGLISH TRANSLATION AND GAMEPLAY FIXES - v3.7
Cumulative README - updated October 15, 2026

ABOUT THIS PATCH

An English translation and gameplay-fix package for the Japanese PlayStation
release of Rockman 6 Complete Works. This single BPS includes the earlier
translation, naming changes, gameplay fixes, menu repairs, v3.6 artwork
translation, and the v3.7 banner correction. No earlier patches or separate NES translation patches are needed.

Apply it ONCE to the matching ORIGINAL, UNMODIFIED ROCKMAN6.mdf.
Do not apply it over an earlier patched image. This package is for PS1;
the separate NES ROM patches are not compatible with it.

COMPLETE LIST OF INCLUDED CHANGES

Gameplay and sound
- Jump out of a slide: release Down, then press Jump again while sliding.
- Retains the PS1 version's headroom checks. This ports the slide-jump
  behavior, not every modification in the reference NES slide patch.
- Suppresses the regular-shot sound when firing a charged shot, preventing
  the two effects from playing together.
- Fully charged Buster shots use the blast sound from the weapon-get
  animation with the large Mega Man sprite and color change.
- Ordinary shots keep their regular sound. Medium-charge shots retain the
  charge-shot effect rather than using the full-charge weapon-get blast.
- These gameplay changes work in both Original Mode and Navi Mode.

Original game translation and naming
- Ports the NES English translation into the PS1 game.
- Includes the Mega Man logo/name addendum with its English subtitle.
- Changes the pause-menu R. BUSTER name to M. BUSTER.
- Translates Navi weapon labels and uses Mega Man / Dr. Light naming in
  the additional menu and gallery graphics edited by this project.

PS1 menus and dialogue
- English mode selection, options, difficulty, controls, screen-position
  settings, and other translated system menu labels.
- English Dr. Light's Lab menus, greetings, upgrade names and descriptions.
- All 177 Navi hints, comprising 351 English pages.
- All 60 enemy/boss database names and descriptions.
- All 14 Navi pause-menu weapon, item and form descriptions.
- English stage-map names and captions.
- English Sound Room controls, including Track, Play, Stop and Mode Select.
- All four bonus Mission Mode titles, objectives and time limits, along
  with mission-clear, result, new-record, game-over and retry labels.
- English PS1-side PocketStation download, link and reset prompts.
- English load, save, error and confirmation prompts.
- Normal unlock requirements are retained; the patch does not unlock
  missions, gallery entries or other rewards automatically.

Menu repairs and stability
- Repairs 24 gameplay memory-card and quit-confirmation messages that
  displayed garbled text in earlier builds.
- Corrects five startup automatic-loading and memory-card notices.
- Reduces pause-menu lettering size and adds spacing beside the yellow icons.
- Restores the full yellow pause-menu icons instead of cutting them in half.
- Fixes the Navi quit-to-title freeze by using the compact confirmation
  RETURN TO TITLE? so the shared text-object pool is not exhausted.
- Restores password-screen memory-card icons, load/save arrows, Select
  button instructions and the triangle cancel icon. Their lettering is
  translated while the surrounding button/icon artwork is preserved.

Opening screens and menu artwork
- Translates Wily's illustrated opening play/break notice.
- Changes the loading-screen caption to NOW LOADING...
- Adds the English Mega Man 6 logo and subtitle to loading/title artwork.
- Changes yellow title and menu banners to MEGA MAN COMPLETE WORKS.
- Translates Dr. Light's encouragement in the Navi Mode preview picture.
- Changes the Lab preview heading to DR. LIGHT'S LAB.

Battle Ranking artwork gallery (inside Dr. Light's Lab)
- Entry 70: English Mega Man biography and MEGA MAN heading.
- Entries 72 and 77: MEGA MAN 6 and MEGA MAN 3 border titles.
- Entry 73: English Power Adaptor instructions and POWER MEGA MAN heading.
- Entry 74: English Jet Adaptor instructions and JET MEGA MAN heading.
- Entry 75: MEGA MAN FAMILY and Dr. LIGHT labels. ROCK remains the
  character's civilian name in this pre-battle family illustration.
- Entry 76: English Roll's dream caption.
- Entry 78: English MEGA MAN and TO THE BEACH! border captions.
- Entry 79: English thank-you message and hidden-mode hint.
- Entry 71's illustration is retained unchanged.
- Main character illustrations are retained. The four prose panels use
  clean text backgrounds for readability. Original indexed palettes and
  resource sizes are preserved, as are pixels outside the edited regions.

VERSION HISTORY

Early ports / v2 foundation
- Established the native PS1 slide-jump and charged-shot sound fixes.
- Ported the NES English text, Mega Man logo/name changes and M. BUSTER label.

v3 - PS1 English translation
- Added the PS1 menu, Lab, Navi, database, equipment-help, stage-caption,
  Sound Room, Mission Mode and PS1-side PocketStation translations.
- Incorporated the earlier native PS1 gameplay fixes and NES-derived text.
- At this point, medium and full charges used the same charge-shot effect.

v3.1 - Weapon Blast
- Changed only fully charged Buster shots to the requested weapon-get blast.
- Preserved normal and medium-charge sounds and suppressed regular-shot
  overlap on charged shots.

v3.2 - Menu Fixes
- Repaired gameplay memory-card/quit notices and startup card notices.
- Reduced pause-menu lettering size to improve icon spacing.

v3.3 - Full Icons
- Restored the entire yellow pause-menu icons and a gap before the text.

v3.4 - Quit Freeze Fix
- Shortened the quit confirmation to prevent the freeze with Navi dialogue.
- Retained the repaired card notices, icon spacing and gameplay changes.

v3.5 - Password Controls
- Restored password-screen card artwork, arrows, Select instructions and
  the triangle cancel icon while translating their lettering.

v3.6 - Gallery and Opening Translation
- Added the Battle Ranking gallery translations listed above.
- Translated Wily's opening notice and the loading caption.
- Updated loading/title logos, Complete Works banners and Navi/Lab preview
  artwork to English and Mega Man naming.
- Includes every preceding release's retained fixes and translations.

v3.7 - Banner Fix
- Enlarges MEGA MAN to match the adjacent COMPLETE WORKS lettering.
- Clears the full original ROCKMAN word, including its bottom pixel rows.
- Only the shared menu banner pixels and sector checksums differ from v3.6.

HOW TO APPLY

1. Keep a backup of your original MDF and matching MDS.
2. Use a BPS-compatible patching program to apply:
   Mega Man 6 PS1 - English v3.7 Banner Fix.bps
3. Select the ORIGINAL, UNMODIFIED ROCKMAN6.mdf as the source file.
   Do not use a previous patched MDF, a converted BIN or a NES ROM.
4. Keep the original matching MDS beside the patched MDF. Use matching
   base filenames, such as ROCKMAN6.mds and ROCKMAN6.mdf.
5. Open the MDS in your emulator and start with a fresh boot. Do not load
   an emulator save state from an older build; it contains old code/artwork.

The ZIP includes the BPS, this README and verification.json. It does not
include the game image, BIOS, emulator or patching program.
If you already have the supplied v3.7 MDF/MDS, it is already patched.

REQUIRED SOURCE AND OUTPUT CHECKSUMS

Source: original ROCKMAN6.mdf
Size: 533879424 bytes (2448-byte sectors, including subchannel data)
CRC32: 51397E10
SHA256: 6526675fd0350e01693f7482494190c9398d7b30fc378adacacd5e74e050d60a

Output: v3.7 patched ROCKMAN6.mdf
Size: 533879424 bytes
CRC32: 416661FD
SHA256: f8bfb71a61e165f71ae92f25b237c87d5793a589a45b80edba81090461abb3dc

TESTING STATUS

- v3.7: BPS reapplication and sector checks passed. Cold boot, mode select
  and the fourth mission screen were checked in Octoshock. The corrected
  banner was visually reviewed. A binary comparison verifies that only
  banner pixels and sector checksums differ from v3.6; gameplay is unchanged.
- v3.7 has not yet been user-tested in DuckStation or on a burned disc.
  The earlier-release results below apply to those stated releases.

- The saved BPS was independently reapplied and matched the complete MDF.
- Modified sectors passed EDC/ECC validation; headers and subchannel data
  were preserved.
- Final v3.6 cold-boot tests in BizHawk Octoshock checked opening screens,
  banners, all ten gallery panels, gallery wraparound/exit, Sound Room
  controls, and all four unlocked mission descriptions.
- Both gameplay modes passed slide-jump and normal/medium/full shot-sound
  checks. Sound requests were 23 / 28 / 61 hexadecimal, respectively.
- Quit regression tests passed 12 repeated quit/cancel cycles, long Navi
  hint cases, and return to title followed by starting a new stage.
- The Navi, database and equipment-help catalogs were checked during the
  earlier translation work. Unlocks used for testing changed emulator RAM
  only, not the disc's unlock rules.
- User report, October 14, 2026: v3.6 works well in DuckStation.
- An earlier v3.4 build was reported working from a burned disc on PS2.
  The burned-disc/PS2 test of v3.6 is still pending.
- No full playthrough, physical memory-card save/format verification or
  physical PocketStation transfer test has been completed for this release.
- Mission completion/results were not exercised in the v3.6 test run.

KNOWN REMAINING JAPANESE

- Entry 78's tiny comic title and speech bubbles. The large border captions
  are translated, but the embedded print is too unclear at the stored
  resolution for a reliable transcription.
- The downloaded PocketStation mini-game itself. Its PS1-side menus and
  prompts are translated.

CREDITS / PROVENANCE

Original game: Capcom.
Original NES English translation source: Her-Saki.
Mega Man logo/name addendum (with subtitle): DartVaderX.
NES slide-fix behavior used as a reference: Puresabe.
Charge-shot correction: based on the user's supplied IPS and requested behavior.
PS1-exclusive translation, artwork text edits and native port work: this project.
Source patch authors have not been represented as endorsing or testing this port.

DISTRIBUTION

Share the patch-only ZIP and its documentation. Do not include game images,
NES ROMs, BIOS files, emulator binaries or test save states.
